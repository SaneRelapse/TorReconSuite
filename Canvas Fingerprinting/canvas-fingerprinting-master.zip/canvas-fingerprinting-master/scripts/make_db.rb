#!/usr/bin/env ruby

require_relative '../model.rb'

c = Create.new
c.up

require_relative '../experiments.rb'

